# Get data from user
userName = input("Enter your name: ")
ssn = input("Enter your SSN: ")
phone = input("Enter your phone number: ")
salary = input("Enter your salary: ")
email = input("Enter your email: ")

# Display data
print()
print(f"---------- {userName} ----------")
print()
print(f"SSN: {ssn}")
print(f"Phone: {phone}")
print(f"Email: {email}")
print(f"Salary: ${salary}")
print()
print("-----------------------")