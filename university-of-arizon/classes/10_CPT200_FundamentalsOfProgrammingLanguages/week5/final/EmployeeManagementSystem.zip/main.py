# Initialize an empty list to store employee data and a counter for the number of employees
employees = []
employee_count = 0  # This is our global counter



############### Function to collect data for a new employee ###############
def collect_employee_data():
    global employee_count  # Access the global variable

    # Gather employee information
    employeeName = input("Enter your name: ")
    employeeSSN = input("Enter your SSN: ")
    employeePhone = input("Enter your phone number: ")
    salary = input("Enter your salary: ")
    email = input("Enter your email: ")

    # Append employee data to the list
    employees.append([employeeName, employeeSSN, employeePhone, salary, email])

    # Increment the counter when a new employee is added
    employee_count += 1



############### Function to display all employees in the system ###############
def view_all_employees():
    print("\nEmployee data:")
    for emp in employees:
        print("-" * 70)  # Separator line
        print(f"{' ' * 28} {emp[0]} ")  # Print employee name
        print(f"SSN: {emp[1]}")
        print(f"Phone: {emp[2]}")
        print(f"Email: {emp[4]}")
        print(f"Salary: ${emp[3]}")
        print("-" * 70)  # Separator line



############### Function to delete an employee ###############
def delete_employee():
    global employee_count  # Access the global variable
    ssn_to_delete = input("Enter the SSN of the employee you want to delete: ")
    for emp in employees:
        if emp[1] == ssn_to_delete:
            employees.remove(emp)
            employee_count -= 1  # Decrement the counter when an employee is deleted
            print(f"Employee with SSN {ssn_to_delete} has been deleted.")
            break
    else:
        print(f"No employee found with SSN {ssn_to_delete}.")


############### Function to search for an employee by SSN and display their information ###############
def search_employee_by_ssn():
    ssn_to_search = input("Enter the SSN of the employee you want to search: ")
    for emp in employees:
        if emp[1] == ssn_to_search:
            print("-" * 70)  # Separator line
            print(f"{' ' * 28} {emp[0]} ")  # Print employee name
            print(f"SSN: {emp[1]}")
            print(f"Phone: {emp[2]}")
            print(f"Email: {emp[4]}")
            print(f"Salary: ${emp[3]}")
            print("-" * 70)  # Separator line
            break
    else:
        print(f"No employee found with SSN {ssn_to_search}.")



############### Function to edit employee information ###############
def edit_employee_information():
    ssn_to_edit = input("Enter the SSN of the employee you want to edit: ")
    for emp in employees:
        if emp[1] == ssn_to_edit:
            print("Employee found. Please select the field to edit:")
            print("1. Name")
            print("2. Phone")
            print("3. Email")
            print("4. Salary")
            choice = input("Enter your choice (1/2/3/4): ")
            if choice == "1":
                emp[0] = input("Enter the new name: ")
            elif choice == "2":
                emp[2] = input("Enter the new phone number: ")
            elif choice == "3":
                emp[4] = input("Enter the new email: ")
            elif choice == "4":
                emp[3] = input("Enter the new salary: ")
            else:
                print("Invalid choice. Please enter 1, 2, 3, or 4.")
            print("Employee information updated.")
            break
    else:
        print(f"No employee found with SSN {ssn_to_edit}.")



############### Function to export employees' information to a text file ###############
def export_employee_data_to_file():
    with open("employee_data.txt", "w") as file:
        for emp in employees:
            file.write(f"{emp[0]}, {emp[1]}, {emp[2]}, {emp[3]}, {emp[4]}\n")
    print("Employee data exported to 'employee_data.txt'.")



############### Function to import employees' information from a text file ###############
def import_employee_data_from_file():
    try:
        with open("employee_data.txt", "r") as file:
            lines = file.readlines()
            for line in lines:
                data = line.strip().split(", ")
                employees.append(data)
        print("Employee data imported from 'employee_data.txt'.")
    except FileNotFoundError:
        print("No preexisting employee data found.")



############### Main function to run the Employee Management System ###############
def main():
    global employee_count

    while True:
        # Display header
        print("-" * 80)  # Print 80 dashes
        print("------------------------ Employee Management System ---------------------------")
        print()
        print(f"There are ( {employee_count} ) employees in the system.")
        print()
        print("-" * 80)  # Print 80 dashes
        print()

        # Display menu options
        print("1. Add new employee")
        print("2. View all employees")
        print("3. Search employee by SSN")
        print("4. Edit employee information")
        print("5. Export employees’ information into a text file")
        print("6. Import employees’ information from a text file")
        print("7. Exit")
        print()
        print("-" * 80)  # Print 80 dashes
        print()

        # Capture user input
        choice = input("Please enter your option number: ")

        if choice == "1":
            collect_employee_data()
        elif choice == "2":
            view_all_employees()
        elif choice == "3":
            search_employee_by_ssn()
        elif choice == "4":
            edit_employee_information()
        elif choice == "5":
            export_employee_data_to_file()
        elif choice == "6":
            import_employee_data_from_file()
        elif choice == "7":
            break
        else:
            print("Invalid choice. Please enter a number between 1 and 7.")


if __name__ == "__main__":
    main()